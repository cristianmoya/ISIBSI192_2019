<?php
	if($_POST) 
	{	
		$num1 = $_POST
		['numero1'];
		$num2 = $_POST
		['numero2'];
		$suma = $num1 
		+ $num2;
		$resta = $num1 
		- $num2;
		$multiplicacion =$num1 
		* $num2;
		$division 
		= $num1 
		/ $num2;
		echo "La suma de ".$num1." y ".$num2." es ".$suma,
		 "<br/> La resta de ".$num1." y ".$num2." es ".$resta,
		  "<br/> La multipliacion de ".$num1." y ".$num2." es ".$multiplicacion,
		  "<br/> La division de ".$num1." y ".$num2." es ".$division; 
	}
?>