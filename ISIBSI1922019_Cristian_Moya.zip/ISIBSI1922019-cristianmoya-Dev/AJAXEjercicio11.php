<!DOCTYPE HTML>
<html lang="es-ES">
<head>
	<meta charset="UTF-8">
	<title>Ejercico 11</title>
</head>
<body>
<H2>Calculadora</H2>
<form action="AJAXEjercicio11a.php" method="POST">
	<table>
	<tr>
		<td><input type="text" name="numero1"></td>
	</tr>
	<tr>
		<td><input type="text" name="numero2"></td>
	</tr>
	<tr>
		<td> <input type="submit" value="sumar"> 
		 <input type="submit" value="restar"> 
		<input type="submit" value="dividir"> 
		 <input type="submit" value="multiplicar"> </td>
	</tr>
</table>
</form>
</body>
</html>
