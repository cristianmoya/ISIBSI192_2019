<html>
 <head>
  <title>Prueba de PHP</title>
 </head>
 <body>
 
 <h1>Ejercicio 10</h1>
   <?php echo '<p>Reservacion de vehiculo</p>'; ?>


 

 <form action="PHPEjercicio10a.php" method="post">
<p>Transporte Seleccion:
<select name="transporte1">
	<option>Sedan </option>
	<option>Todo terreno</option>
	<option>Compacto</option>
</select>
<p>Transporte personas radio:
<input type="radio" name="personas" value="1">Una
<br>
<input type="radio" name="personas" value="2">Dos
<br>
<input type="radio" name="personas" value="3">Tres 
<br>
<input type="radio" name="personas" value="2">Cuatro
<br>
<input type="radio" name="personas" value="2">Cinco
<br>
</p>

 <p>Nombre: <input type="text" name="nombre" /></p>
<p>Contraseña: <input type="password" name="contras" /></p>
<p>Notas: <textarea name="opinion">GPS, seguros, etc: </textarea></p>

<p><input type="submit" value="Boton enviar" /></p>

</form>
 </body>
</html>