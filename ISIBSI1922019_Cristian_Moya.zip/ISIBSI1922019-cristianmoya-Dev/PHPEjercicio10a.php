<html>
<head>
<title>Recoger datos</title> 
</head>
<body>
<h1>Estos son los datos de la reservacion:</h1>
<?php  
echo "Tu transporte: "; echo $_POST['transporte1']; echo "<br/>";
echo "Cantidad de personas : "; echo $_POST['personas']; echo "<br/>";
echo "Tu nombre: "; echo $_POST['nombre']; echo "<br/>";
echo "Tu contraseña: "; echo $_POST['contras']; echo "<br/>";
echo "Tu opinión: "; echo $_POST['opinion']; echo "<br/>";
?>
</body>
</html>